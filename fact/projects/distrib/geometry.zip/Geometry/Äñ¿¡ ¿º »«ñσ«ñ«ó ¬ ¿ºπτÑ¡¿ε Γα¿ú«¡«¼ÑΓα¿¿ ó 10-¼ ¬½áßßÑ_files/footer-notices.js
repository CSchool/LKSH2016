function initNotices(parameters)
{var apiPlace=(typeof parameters.apiPlace!=='undefined')?parameters.apiPlace:'//partner.1september.ru/api/1.0/notices.json';var apiStaticPlace=(typeof parameters.apiStaticPlace!=='undefined')?parameters.apiStaticPlace:'//partner.1september.ru';var interval=(typeof parameters.interval!=='undefined')?parameters.interval:15000;if('withCredentials'in new XMLHttpRequest()){$.getJSON(apiPlace,{place:parameters.place},processNoticesData);}else{$.ajax({method:'GET',url:apiPlace+'p',dataType:'jsonp',jsonpCallback:'noticesDataJsonpCallback',data:{place:parameters.place},success:processNoticesData,cache:true,});}
function processNoticesData(data,status,jqXHR)
{if(data.notices){createNoticesBlock(apiStaticPlace,data.notices);if($("#footer-notices .notices .notice").length>1){window.setInterval(function(){$("#footer-notices").rotateNotices($(".notices"),$(".logos"));},interval);}}}
function createNoticesBlock(apiStaticPlace,notices)
{var allNotices='';$.each(notices,function(index,notice){allNotices+='<div class="notice '+notice.partner+'"  style="display: none">';if(notice.date){allNotices+='<span class="date">'+notice.date+'</span>';}
if(notice.url){allNotices+='\
          <a href="'+notice.url+'" title="Подробнее" target="_blank">\
            <span class="text">'+notice.text+'</span>\
          </a>';}else{allNotices+='<span class="text">'+notice.text+'</span>';}
allNotices+='</div>';});var logos={drofa:{title:"Издательство «Дрофа»",link:{hash:"FDGVfciVAh",description:"Сайт издательства «Дрофа»",},images:{width:128,height:35,x1:"drofa-logo.png",x2:"drofa-logo@2x.png",x3:"drofa-logo@3x.png",}},ventana:{title:"Издательский центр «Вентана Граф»",link:{hash:"Ht653d1P9N",description:"Сайт издательского центра «Вентана Граф»",},images:{width:106,height:35,x1:"ventana-logo.png",x2:"ventana-logo@2x.png",x3:"ventana-logo@3x.png",}}};var content='\
      <link href="'+apiStaticPlace+'/css/notices.css" rel="stylesheet" type="text/css">\
      \
      <table id="footer-notices"><tr>\
        <td class="logos">';$.each(logos,function(logoId,logoData){content+='\
        <div class="logo '+logoId+'" style="display: none">\
          <a href="//click.1september.ru/'+logoData.link.hash+'" title="'+logoData.link.description+'" target="_blank">\
            <img src="'+apiStaticPlace+'/img/'+logoData.images.x1+'"\
              srcset="\
                '+apiStaticPlace+'/img/'+logoData.images.x1+' 1x,\
                '+apiStaticPlace+'/img/'+logoData.images.x2+' 2x,\
                '+apiStaticPlace+'/img/'+logoData.images.x3+' 3x\
              " width="'+logoData.images.width+'" height="'+logoData.images.height+'" alt="'+logoData.title+'">\
          </a>\
        </div>';});content+='\
        </td>\
        \
        <td class="arrow">\
          <img src="'+apiStaticPlace+'/img/arrow.png"\
            srcset="\
              '+apiStaticPlace+'/img/arrow.png 1x,\
              '+apiStaticPlace+'/img/arrow@2x.png 2x,\
              '+apiStaticPlace+'/img/arrow@3x.png 3x\
            " width="19" height="45" alt="&gt;">\
          \
        </td>\
        \
        <td class="notices">'+allNotices+'</td>\
      </tr></table>\
    ';$('body').css('margin-bottom','60px').append($(content));$("#footer-notices").find(".notices .notice:first").css("display","block").end().find(".logos .logo."+notices[Object.keys(notices)[0]].partner).css("display","block");}
jQuery.fn.extend({rotateNotices:function(noticesContainer,logosContainer)
{if(noticesContainer.find(".notice:last-child").is(":visible")){noticesContainer.find(".notice:visible").css("display","none");noticesContainer.find(".notice:first").css("display","block");}else{noticesContainer.find(".notice:visible").css("display","none").next(".notice").css("display","block");}
var activeNotice=noticesContainer.find(".notice:visible").first();var activeLogo=logosContainer.find(".logo:visible").first();if(!activeLogo||(activeNotice.hasClass("drofa")&&!activeLogo.hasClass("drofa"))||(activeNotice.hasClass("ventana")&&!activeLogo.hasClass("ventana"))){logosContainer.find(".logo:visible").css("display","none");if(activeNotice.hasClass("drofa")){logosContainer.find(".logo.drofa").css("display","block");}else if(activeNotice.hasClass("ventana")){logosContainer.find(".logo.ventana").css("display","block");}}}});}